This folder comprises a Hail (www.hail.is) native Table or MatrixTable.
  Written with version 0.2.108-fc03e9d5dc08
  Created at 2023/03/26 18:28:18